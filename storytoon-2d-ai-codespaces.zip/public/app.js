const $=id=>document.getElementById(id),canvas=$("stage"),ctx=canvas.getContext("2d");
let scenes=[],timer=null;const W=720,H=1280,SEG=4.5;
$("story").addEventListener("input",()=> $("count").textContent=$("story").value.length+"/3000 karakter");
$("generate").onclick=generate;$("play").onclick=play;$("export").onclick=exportVideo;
function status(t){$("status").textContent=t}
function esc(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function generate(){
 const story=$("story").value.trim();if(!story)return status("Tulis cerita dulu ya.");
 $("generate").disabled=true;status("AI sedang menyusun cerita menjadi beberapa adegan...");
 try{const r=await fetch("/api/storyboard",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({story})});const d=await r.json();if(!r.ok)throw Error(d.error);
 scenes=d.scenes;$("scenes").classList.remove("empty");
 $("scenes").innerHTML=scenes.map((s,i)=>`<article class="scene"><strong>SCENE ${i+1} · ${esc((s.setting||"scene").toUpperCase())}</strong><p>${esc(s.caption||s.narration)}</p><small>${esc(s.visual)}</small></article>`).join("");
 $("play").disabled=$("export").disabled=false;draw(0,0);status(d.mode==="ai"?"Storyboard AI berhasil dibuat.":"Storyboard dasar dibuat. Tambahkan API key untuk hasil AI.");}
 catch(e){status(e.message||"Terjadi kesalahan.")}finally{$("generate").disabled=false}
}
const palettes={castle:["#8fc8ed","#e9d7a4","#4f9b64"],battlefield:["#91cbed","#e8d7a3","#70a34c"],village:["#a5d7ed","#efd9a9","#6b9e5b"],interior:["#4b4560","#bd8b62","#493b39"],map:["#9bc77b","#d8c18b","#638a52"],night:["#17264d","#5a547a","#33465a"]};
function rounded(x,y,w,h,r,fill,stroke){ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=5;ctx.stroke()}}
function cloud(x,y,s){ctx.fillStyle="#fff9e9";ctx.globalAlpha=.9;ctx.beginPath();ctx.arc(x,y,36*s,0,7);ctx.arc(x+40*s,y-18*s,48*s,0,7);ctx.arc(x+86*s,y,34*s,0,7);ctx.fill();ctx.globalAlpha=1}
function tree(x,y,s){ctx.fillStyle="#79513a";ctx.fillRect(x-9*s,y,18*s,65*s);ctx.fillStyle="#4c8954";for(let i=0;i<3;i++){ctx.beginPath();ctx.arc(x,y-18*s-i*25*s,34*s-i*4*s,0,7);ctx.fill()}}
function castle(x,y,s){ctx.fillStyle="#d9c7a5";ctx.strokeStyle="#786b5b";ctx.lineWidth=5;ctx.fillRect(x,y,220*s,175*s);ctx.strokeRect(x,y,220*s,175*s);for(let k=0;k<2;k++){let tx=x-25*s+k*220*s;ctx.fillRect(tx,y-75*s,55*s,250*s);ctx.strokeRect(tx,y-75*s,55*s,250*s);ctx.fillStyle="#a95e55";ctx.beginPath();ctx.moveTo(tx-5*s,y-75*s);ctx.lineTo(tx+27*s,y-135*s);ctx.lineTo(tx+60*s,y-75*s);ctx.fill();ctx.fillStyle="#d9c7a5";}ctx.fillStyle="#73534a";ctx.beginPath();ctx.arc(x+110*s,y+175*s,38*s,Math.PI,0);ctx.fill();ctx.fillRect(x+72*s,y+175*s,76*s,0)}
function person(x,y,s,color,king=false,shield=false){
 ctx.save();ctx.translate(x,y);ctx.scale(s,s);
 // shadow
 ctx.fillStyle="#24312c55";ctx.beginPath();ctx.ellipse(0,150,58,13,0,0,7);ctx.fill();
 // cloak/body
 ctx.fillStyle=color;ctx.strokeStyle="#403b38";ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(-38,45);ctx.quadraticCurveTo(-55,105,-48,145);ctx.lineTo(48,145);ctx.quadraticCurveTo(55,85,38,45);ctx.closePath();ctx.fill();ctx.stroke();
 // head
 ctx.fillStyle="#fff9e9";ctx.beginPath();ctx.arc(0,10,42,0,7);ctx.fill();ctx.stroke();
 // ears and face
 ctx.fillStyle="#fff9e9";ctx.beginPath();ctx.arc(-40,15,9,0,7);ctx.arc(40,15,9,0,7);ctx.fill();
 ctx.fillStyle="#282d31";ctx.beginPath();ctx.arc(-14,8,4,0,7);ctx.arc(14,8,4,0,7);ctx.fill();
 ctx.strokeStyle="#59413b";ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,22,11,.2,Math.PI-.2);ctx.stroke();
 if(king){ctx.fillStyle="#e8b943";ctx.strokeStyle="#77542c";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-34,-25);ctx.lineTo(-30,-65);ctx.lineTo(-10,-43);ctx.lineTo(0,-72);ctx.lineTo(13,-43);ctx.lineTo(32,-64);ctx.lineTo(35,-25);ctx.closePath();ctx.fill();ctx.stroke()}
 if(shield){ctx.fillStyle="#d6b66f";ctx.strokeStyle="#473f39";ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(48,62);ctx.lineTo(95,70);ctx.lineTo(88,125);ctx.lineTo(68,145);ctx.lineTo(48,125);ctx.closePath();ctx.fill();ctx.stroke();ctx.strokeStyle="#8b5147";ctx.beginPath();ctx.moveTo(72,72);ctx.lineTo(72,132);ctx.stroke()}
 ctx.restore();
}
function draw(i,p=0){
 if(!scenes.length)return;const s=scenes[i],setting=(s.setting||"castle").toLowerCase(),pal=palettes[setting]||palettes.castle;
 let sky=ctx.createLinearGradient(0,0,0,900);sky.addColorStop(0,pal[0]);sky.addColorStop(1,pal[1]);ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
 if(setting==="night"){ctx.fillStyle="#fff0bd";ctx.beginPath();ctx.arc(560,190,65,0,7);ctx.fill();for(let n=0;n<55;n++){ctx.fillStyle="#fff";ctx.globalAlpha=.4+(n%4)*.12;ctx.fillRect((n*113)%W,(n*71)%500,3,3)}ctx.globalAlpha=1}
 else{cloud(100+p*30,180,.9);cloud(430-p*20,260,1.1);cloud(650,130,.65)}
 // hills and landscape
 ctx.fillStyle=pal[2];ctx.beginPath();ctx.moveTo(0,690);ctx.quadraticCurveTo(180,570,360,700);ctx.quadraticCurveTo(530,560,720,690);ctx.lineTo(720,1050);ctx.lineTo(0,1050);ctx.fill();
 if(setting==="map"){
  ctx.fillStyle="#d4b77f";ctx.fillRect(0,470,W,480);ctx.strokeStyle="#b58e58";ctx.lineWidth=18;ctx.beginPath();ctx.moveTo(360,450);ctx.bezierCurveTo(250,600,490,700,350,960);ctx.stroke();
  for(let n=0;n<7;n++){ctx.fillStyle=n%2?"#a94f43":"#426a9b";ctx.beginPath();ctx.arc(100+n*82,570+(n%2)*210,13,0,7);ctx.fill()}
 }else if(setting==="interior"){
  ctx.fillStyle="#483b3a";ctx.fillRect(0,0,W,900);ctx.fillStyle="#d5a16a";ctx.fillRect(0,750,W,300);
  for(let x=40;x<720;x+=160){ctx.fillStyle="#76544a";ctx.fillRect(x,80,22,670)}
  rounded(245,310,230,320,12,"#9d6549","#44352f");ctx.fillStyle="#ffd17c";ctx.beginPath();ctx.arc(360,550,55,Math.PI,0);ctx.fill();
 }else{
  if(setting==="castle"){castle(250,485,1.05)}
  if(setting==="village"){for(let x=75;x<680;x+=190){ctx.fillStyle="#e6d0a5";ctx.fillRect(x,570,125,115);ctx.fillStyle="#a85d4e";ctx.beginPath();ctx.moveTo(x-12,570);ctx.lineTo(x+62,500);ctx.lineTo(x+138,570);ctx.fill()}tree(80,690,1);tree(650,680,.9)}
  if(setting==="battlefield"){
   ctx.fillStyle="#b99b68";ctx.beginPath();ctx.moveTo(310,650);ctx.lineTo(410,650);ctx.lineTo(720,1080);ctx.lineTo(0,1080);ctx.fill();
   for(let n=0;n<8;n++){person(65+n*82,750+(n%2)*70,.55,n%2?"#3f6e9e":"#a94e43",false,n%2===0)}
   for(let n=0;n<7;n++)person(90+n*90,550+(n%2)*55,.42,"#496d9b",false,true);
  }
 }
 // little trees / fencing in far edges
 if(setting!=="interior"&&setting!=="map"){tree(55,720,.75);tree(665,700,.8)}
 if(setting!=="battlefield"&&setting!=="map")person(360,760,.95,"#a94e43",true,true);
 // story caption strip
 const caption=s.caption||s.narration||"";rounded(30,1005,660,230,22,"rgba(20,25,32,.86)","#f0d9a5");
 ctx.textAlign="center";ctx.fillStyle="#f1ca83";ctx.font="bold 25px system-ui";ctx.fillText(`CHAPTER ${String(i+1).padStart(2,"0")}`,360,1050);
 ctx.fillStyle="#fff";ctx.font="bold 34px system-ui";wrap(caption,360,1110,590,43,3);
 ctx.fillStyle="#e8d8b8";ctx.font="18px system-ui";ctx.fillText("STORYTOON 2D",360,1208);
}
function wrap(text,x,y,max,line,maxN){let words=String(text).split(/\s+/),arr=[],cur="";for(let w of words){let t=cur?cur+" "+w:w;if(ctx.measureText(t).width>max&&cur){arr.push(cur);cur=w}else cur=t}if(cur)arr.push(cur);arr.slice(0,maxN).forEach((v,j)=>ctx.fillText(v,x,y+j*line))}
function play(){clearInterval(timer);let start=Date.now();timer=setInterval(()=>{let t=(Date.now()-start)/1000;if(t>=scenes.length*SEG){clearInterval(timer);draw(0);return}let i=Math.floor(t/SEG);draw(i,(t%SEG)/SEG)},40)}
function exportVideo(){
 if(!scenes.length)return;if(!canvas.captureStream||!window.MediaRecorder){status("Browser HP belum mendukung perekaman. Coba Chrome terbaru.");return}
 const mime=["video/webm;codecs=vp9","video/webm;codecs=vp8","video/webm"].find(x=>MediaRecorder.isTypeSupported(x));if(!mime){status("Format video tidak didukung browser.");return}
 $("export").disabled=true;status("Merekam video... tunggu sampai selesai dan jangan tutup halaman.");
 const stream=canvas.captureStream(30),chunks=[],rec=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:5000000});
 rec.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};rec.onstop=()=>{let url=URL.createObjectURL(new Blob(chunks,{type:mime})),a=document.createElement("a");a.href=url;a.download="storytoon-2d.webm";a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);stream.getTracks().forEach(t=>t.stop());$("export").disabled=false;status("Selesai! Video tersimpan di folder Download HP.");};
 rec.start();let start=Date.now();let iv=setInterval(()=>{let t=(Date.now()-start)/1000;if(t>=scenes.length*SEG){clearInterval(iv);draw(scenes.length-1,1);rec.stop();return}draw(Math.floor(t/SEG),(t%SEG)/SEG)},33);
}
draw(0);
