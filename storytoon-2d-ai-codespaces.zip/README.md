# StoryToon 2D AI

Aplikasi web mobile-first untuk mengubah teks cerita menjadi storyboard kartun 2D vertikal.

## Jalankan di GitHub Codespaces
1. Upload isi folder project ini ke repository GitHub.
2. Buka Code → Codespaces → Create codespace.
3. Di terminal:
   ```bash
   npm install
   cp .env.example .env
   ```
4. Edit `.env`, isi `OPENAI_API_KEY` dengan API key milikmu (opsional untuk mode AI).
5. Jalankan `npm start`.
6. Buka tab Ports, port 3000 → Open in Browser.

Tanpa API key, aplikasi tetap bisa dicoba dalam mode storyboard dasar. Dengan API key, AI akan menyusun 6–8 scene dari cerita.

## Catatan
- Versi ini membuat ilustrasi kartun 2D prosedural (bukan gambar AI per scene).
- Export video saat ini berupa WebM; dukungan tergantung browser.
- Jangan pernah commit file `.env` atau membagikan API key.
