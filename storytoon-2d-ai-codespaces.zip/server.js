import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
dotenv.config();
const app=express(), __dirname=path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));
app.post("/api/storyboard",async(req,res)=>{
 const story=String(req.body?.story||"").trim();
 if(!story)return res.status(400).json({error:"Cerita belum diisi."});
 if(!process.env.OPENAI_API_KEY)return res.json({title:"Cerita Kamu",scenes:fallback(story),mode:"basic"});
 try{
  const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
  const r=await client.responses.create({
   model:"gpt-4.1-mini",
   instructions:`Buat storyboard video vertikal kartun sejarah 2D bergaya ilustrasi buku cerita: garis tinta lembut, karakter kepala bulat putih ekspresif, tubuh sederhana berjubah/berzirah, latar watercolor penuh detail, langit biru awan besar, kastil abad pertengahan, warna hangat sinematik. Balas hanya JSON valid: {"title":"judul","scenes":[{"narration":"narasi bahasa Indonesia 1-2 kalimat","caption":"subtitle pendek maksimal 10 kata","visual":"deskripsi adegan konkret dalam bahasa Indonesia","setting":"castle|battlefield|village|interior|map|night","mood":"peace|tension|battle|sad|hope|victory"}]}. Buat 6-8 scene dengan urutan cerita jelas. Visual harus menyebut lokasi, waktu, tokoh, aksi dan properti penting. Jangan menambahkan teks yang harus muncul di gambar.`,
   input:story
  });
  let raw=(r.output_text||"").replace(/^```(?:json)?\\s*/i,"").replace(/\\s*```$/,"");
  const data=JSON.parse(raw);
  if(!Array.isArray(data.scenes)||!data.scenes.length)throw new Error("Storyboard kosong");
  res.json({title:data.title||"Cerita Animasi",scenes:data.scenes.slice(0,8),mode:"ai"});
 }catch(e){console.error(e);res.status(502).json({error:"AI gagal membuat storyboard. Periksa API key atau coba lagi."});}
});
function fallback(story){
 const lines=story.split(/[.!?]+/).map(x=>x.trim()).filter(Boolean);
 const a=lines.length?lines:[story];
 return a.slice(0,6).map((x,i)=>({narration:x,caption:x.length>55?x.slice(0,52)+"...":x,visual:["A medieval castle beneath a bright blue sky","The hero begins a journey along a country road","Two armies gather on a wide green battlefield","A tense meeting inside the royal hall","The turning point of the story","The kingdom celebrates at sunset"][i]||"A storybook scene",setting:["castle","village","battlefield","interior","battlefield","castle"][i]||"castle",mood:["peace","hope","tension","tension","battle","victory"][i]||"hope"}));
}
app.listen(process.env.PORT||3000,"0.0.0.0",()=>console.log("StoryToon 2D berjalan di port "+(process.env.PORT||3000)));
